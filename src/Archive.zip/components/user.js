const setupUser = (() => {
  return () => {
    // Placeholder for future functionality
  };
})();

export { setupUser };
