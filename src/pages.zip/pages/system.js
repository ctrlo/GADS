import { setupHtmlEditor } from "../components/html-editor";

const SytemPage = () => {
  setupHtmlEditor();
};

export { SytemPage };
