import { setupHtmlEditor } from "../components/html-editor";

const ConfigPage = () => {
  setupHtmlEditor();
};

export { ConfigPage };
