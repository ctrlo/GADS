import { setupOtherUserViews } from "../components/other-user-view";

const DataCalendarPage = () => {
  setupOtherUserViews();
};

export { DataCalendarPage };
